<section class="error">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-6">
        <div class="alert alert-danger m-0">Unsupported Layout: <?= $element; ?></div>
      </div>
    </div>
  </div>
</section>
