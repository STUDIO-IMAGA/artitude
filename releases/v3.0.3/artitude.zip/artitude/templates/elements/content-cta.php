<section class="element content-cta">
  <div class="container">
    <div class="row">
      <div class="col-12 text-center">
        <span class="h4 mr-md-3"><? the_sub_field('title'); ?></span>
        <a href="<? the_sub_field('btn_url'); ?>" class="btn btn-black btn-arrow"><? the_sub_field('btn_text'); ?></a>
      </div>
    </div>
  </div>
</section>
