<section class="element content-heading">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 col-md-3">
        <div class="title text-left text-md-right">
          <h2><? the_sub_field('title'); ?></h2>
        </div>
      </div>
      <div class="col-12 col-md-7">
        <div class="text pl-md-4">
          <? the_sub_field('text'); ?>
        </div>
      </div>
    </div>
  </div>
</section>
