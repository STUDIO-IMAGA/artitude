<section class="element content-text">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 col-md-10 col-lg-8 col-xl-6">
        <div class="text" data-aos="fade-up">
          <? the_sub_field('text'); ?>
        </div>
      </div>
    </div>
  </div>
</section>
