<section class="element content-quote">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 col-md-10 col-lg-8 col-xl-6 text-md-center quote" data-aos="fade">
        <div class="text" data-aos="fade-up">
          <p><? the_sub_field('text'); ?></p>
        </div>
        <div class="author" data-aos="fade-down">
          <span>- <? the_sub_field('author'); ?></span>
        </div>
      </div>
    </div>
  </div>
</section>
