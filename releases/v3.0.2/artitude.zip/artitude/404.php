<? get_template_part('templates/header'); ?>

<div class="container">
  <div class="row">
    <div class="col-12">
      <h1>404, pagina niet gevonden</h1>
      <p>Sorry, maar deze pagina konden wij niet vinden.</p>
      <a class="btn btn-black" href="/" target="_self">Terug naar home</a>
    </div>
  </div>
</div>
