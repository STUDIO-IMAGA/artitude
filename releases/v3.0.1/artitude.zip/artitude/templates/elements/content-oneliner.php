<? $align = get_sub_field('align'); ?>
<section class="element content-oneliner">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="text <?= $align; ?>" data-aos="fade-up">
          <? the_sub_field('text'); ?>
        </div>
      </div>
    </div>
  </div>
</section>
