<section class="element content-video">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 col-md-10 col-lg-8 col-xl-7">
        <div class="bg-lines" data-aos="fade-down"></div>
        <div class="embed-responsive embed-responsive-16by9" data-aos="fade-up">
          <video class="embed-responsive-item" src="<? the_sub_field('video'); ?>"></video>
          <div class="btn-play"></div>
          <div class="video-progress progress">
            <div class="progress-bar bg-red" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
